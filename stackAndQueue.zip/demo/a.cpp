#include<iostream>
#include<stack>
#include<queue>

int main() {
    using namespace std;
    stack<int> s;
    queue<int> q;
    cout << "Deverse" << endl;
    for (int i = 0; i < 10; i++) {
        q.push(i);
        cout << i << "  ";
    }
    cout << endl;
    while (!q.empty()) {
        s.push(q.front());
        q.pop();
    }
    while (!s.empty()) {
        q.push(s.top());
        s.pop();
    }

    cout << "Reverse : " << endl;
    while (!q.empty()) {
        cout << q.front() << "  ";
        q.pop();
    }
    return 0;
}
