#include "stdafx.h"
#include <iostream>
#include <vector>

using namespace std;

vector<vector<int> > matrix(12);
vector<vector<int> > matrixA(12);
vector<vector<int> > matrixB(12);
int A = 0;

void printMatrix(vector<vector<int> > &matrix);

void addMatrix(vector<vector<int> > matrixA, vector<vector<int> > matrixB) {
	unsigned int i, j ;
	for (i = 0; i < matrix.size(); i++) {
		for (j = 0; j < matrix[i].size(); j++) {
			matrix[i][j] = matrixA[i][j] + matrixB[i][j];
		}
	}
}

void subMatrix(vector<vector<int> > matrixA, vector<vector<int> > matrixB) {
	unsigned int i, j;
	for (i = 0; i < matrix.size(); i++) {
		for (j = 0; j < matrix[i].size(); j++) {
			matrix[i][j] = matrixA[i][j] - matrixB[i][j];
		}
	}
}

vector<vector<int> > mulMatrix(vector<vector<int> > matrixA, vector<vector<int> > matrixB) {
	vector<vector<int> > matrixC;
	matrixC = matrix;
	unsigned int i, j, k;
	for (i = 0; i < matrixA.size(); i++) {
		for (j = 0; j < matrixB[i].size(); j++) {
			for (k = 0; k < matrixA[i].size(); k++) {
				matrixC[i][j] += matrixA[i][k] * matrixB[k][j];
			}
		}
	}
	return matrixC;
}

void intMatrix(int A, vector<vector<int> > matrixB) {
	unsigned int i, j;
	for (i = 0; i < matrix.size(); i++) {
		for (j = 0; j < matrix[i].size(); j++) {
			matrix[i][j] = A * matrixB[i][j];
		}
	}
}

vector<vector<int> > powerMatrix(int A, vector<vector<int> > matrixB) {
	vector<vector<int> > matrixC;
	matrixC = matrixB;
	unsigned int i = 0, j = 0;

	for (i = 0; i<matrixC.size(); i++)//�����ά��̬���� 
	{
		for (j = 0; j<matrixC[i].size(); j++)
		{
			if (i == j) {
				matrixC[i][j] = 1;
			}
			else {
				matrixC[i][j] = 0;
			}
		}
	}

	while (A>0)
	{
		if (1 & A) //A������
			matrixC = mulMatrix(matrixC, matrixB);
		matrixB = mulMatrix(matrixB, matrixB);
		A >>= 1;
	}
	return matrixC;
}

void GetSubMatrix(vector< vector<int> >& matrix, unsigned int i, unsigned int j)
{
	vector< vector<int> >::iterator it1;
	vector<int>::iterator it2;
		
	unsigned int idx;

	for (idx = 1, it1 = matrix.begin(); idx<i && it1 != matrix.end(); idx++, it1++)
	{

	}
	if (it1 == matrix.end())
	{
		return;
	}
	else
	{
		matrix.erase(it1);
	}

	for (it1 = matrix.begin(); it1 != matrix.end(); it1++)
	{
		for (idx = 1, it2 = it1->begin(); idx < j&&it2 != it1->end(); idx++, it2++)
		{

		}
		if (it2 == it1->end())
		{
			return;
		}
		else
		{
			it1->erase(it2);
		}
	}
}

int rowAndColMatrix(vector<vector<int> > matrixA, int n) {
	int DetValue = 0;
	vector< vector<int> > temp;
	unsigned int k = 0, j = 0;

	if (n == 1)
	{
		return matrixA[0][0];
	}
	if (n == 2)
	{
		DetValue = matrixA[0][0] * matrixA[1][1] - matrixA[0][1] * matrixA[1][0];
		return DetValue;
	}
	else
	{
		int coe = 1;
		// ÿ�����󶼰���һ��չ�������������ѭ������iΪ����ʱ��������
		// 1���Ϊż������ϵ��Ϊ1����iΪż��ʱ��ż����1Ϊ����ϵ��Ϊ��1��
		for (int i = 1; i <= n; i++)
		{
			if (i % 2 != 0)
			{
				coe = 1;
			}
			else
			{
				coe = -1;
			}
			temp = matrixA;
			int temp2 = temp[0][i - 1];   // ����ϵ��
		
			GetSubMatrix(temp, 1, i); // �����������ʽ����

			DetValue += coe * temp2 * rowAndColMatrix(temp, n - 1);
		}
		return DetValue;
	}
}

int rankMatrix(vector<vector<int> > matrixA) {
	unsigned int i = 0, j = 0;
	int temp = 0, rank = matrixA.size();

	for (i = matrixA.size()-1; i>0; i--)
	{
		for (j = matrixA[i].size()-1; j>0; j--)
		{
			temp += matrixA[i][j];
		}
		if (temp <= 0) {
			rank -= 1;
			temp = 0;
		}
		else {
			return rank;
		}
	}
	return rank;
}

void printMatrix(vector<vector<int>> &matrix) {
	unsigned int i = 0, j = 0;

 	for (i = 0; i<matrix.size(); i++)//�����ά��̬���� 
	{
		for (j = 0; j<matrix[i].size(); j++)
		{
			cout << matrix[i][j] << " ";
		}
		cout << "\n";
	}
}

void inputMatrix(vector<vector<int> > &matrix) {
	unsigned int i = 0, j = 0;

	for (i = 0; i<matrix.size(); i++)//�����ά��̬���� 
	{
		for (j = 0; j<matrix[i].size(); j++)
		{
			cin >> matrix[i][j];
		}
	}
	//printMatrix(matrix);
}

void initMatrix(int row, int col) {
	unsigned int i = 0;
	unsigned int j = 0;

	vector<vector<int> > objs(row); //�����ά��̬����
	vector<vector<int> > obj1(row);
	vector<vector<int> > obj2(row);
	matrix = objs;
	matrixA = obj1;
	matrixB = obj2;
	
	for (i = 0; i<matrix.size(); i++)//��̬��ά����Ϊrow��col��
	{
		matrix[i].resize(col);//��ʼ��Ϊ0
	}

	for (i = 0; i<matrixA.size(); i++)
	{
		matrixA[i].resize(col);
	}

	for (i = 0; i<matrixB.size(); i++)
	{
		matrixB[i].resize(col);
	}
	//printMatrix(objs);
	//printMatrix(obj1);
	//printMatrix(obj2);

}

void inMatrix() {
	cout << "Input Matrix A: \n";
	inputMatrix(matrixA);

	cout << "Input Matrix B: \n";
	inputMatrix(matrixB);
}

void inB() {
	cout << "Input A: \n";
	cin >> A;
	cout << "Input Matrix B: \n";
	inputMatrix(matrixB);
}

void inA() {
	cout << "Input Matrix A: \n";
	inputMatrix(matrixA);
}

void output(vector<vector<int> > &matrix) {
	cout << "Output:\n";
	printMatrix(matrix);
}

void init() {
	int row, col;
	cout << "Please input row less than 10:(��)\n";
	cin >> row;
	cout << "Please input col less than 10:(��)\n";
	cin >> col;

	initMatrix(row, col);
}

int main()
{
	int choice;

	while (1) {

		cout << "-------------Welcome to Calc Matrix----------------\n";
		cout << "------                                    ---------\n";
		cout << "------1������ӷ�                         ---------\n";
		cout << "------                                    ---------\n";
		cout << "------2���������                         ---------\n";
		cout << "------                                    ---------\n";
		cout << "------3������˷�                         ---------\n";
		cout << "------                                    ---------\n";
		cout << "------4���������˷�                       ---------\n";
		cout << "------                                    ---------\n";
		cout << "------5������n����                        ---------\n";
		cout << "------                                    ---------\n";
		cout << "------6������ʽ����                       ---------\n";
		cout << "------                                    ---------\n";
		cout << "------7���������                         ---------\n";
		cout << "------                                    ---------\n";
		cout << "------8��EXIT                             ---------\n";
		cout << "---------------------------------------------------\n";

		cout << "Please choice which one you want to do:\n";
		cin >> choice;

		vector<vector<int> > matrixC;
		int rowAndCol = 0, rank = 0;

		switch (choice) {
		case 1:
			init();
			inMatrix();
			addMatrix(matrixA, matrixB);
			output(matrix);
			break;
		case 2:
			init();
			inMatrix();
			subMatrix(matrixA, matrixB);
			output(matrix);
			break;
		case 3:
			init();
			inMatrix();
			matrixC = mulMatrix(matrixA, matrixB);
			output(matrixC);
			break;
		case 4:
			init();
			inB();
			intMatrix(A, matrixB);	
			output(matrix);
			break;
		case 5:
			init();
			inB();
			matrixC = powerMatrix(A, matrixB);
			output(matrixC);
			break;
		case 6:
			init();
			inA();
			rowAndCol = rowAndColMatrix(matrixA, matrixA.size());
			printf("����ʽΪ��%d\n", rowAndCol);
			break;
		case 7:
			init();
			inA();
			rank = rankMatrix(matrixA);
			printf("�������Ϊ��%d\n", rank);
			break;
		case 8:
			cout << " Will Exit! \n";
			exit(1);
		default:
			exit(1);
			break;
		}

		// print The result of Matrix
		//printMatrix(matrix);

		//continuing
		cout << "please continuing.....";
		cout << "\n\n\n";
		
	}

    return 0;
}

