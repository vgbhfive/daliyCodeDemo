#include <stdio.h>
#include <string.h>
#include <stdlib.h>

typedef struct Student {
	int id; // 学号
	char name[32]; //姓名
	char sex[8]; //性别
	int dorm; //宿舍号
	int phone; //电话
	struct Student *next;
}Student;

typedef struct Grade {
	int id; //学号
	char classId[32]; //课程编号
	char className[64]; //课程名称
	int credit; //学分
	int usual; //平时成绩
	int test; //测试成绩
	int exam; //考试成绩
	int grade; //综合
	int allCredit; //实得学分
	struct Grade *next;
}Grade;

Student *sHead = NULL; //头
Student *sTail = NULL; //尾
Grade *gHead = NULL; //头
Grade *gTail = NULL; //尾

void Print(char str[]) {
	if (str == "grade") {
		Grade *head = gHead;
		while (head != NULL) {
			printf("%d %s %s %d %d %d %d %d %d \n", head->id, head->classId, head->className, head->credit, head->usual, 
				head->test, head->exam, head->grade, head->allCredit);
			head = head->next;	
		}
	} else {
		if (str == "student") {
			Student *head = sHead;
			while (head != NULL) {
				printf("%d %s %s %d %d \n", head->id, head->name, head->sex, head->dorm, head->phone);
				head = head->next;
			}
		} else {
			printf("%s\n", "No thing to print!");
		}
	}
}

void inStudent (Student *stu) {
	if (sHead == NULL) {
		sHead = stu;
		sTail = stu;
	}
	else {
		sTail->next = stu;
		stu->next = NULL;
		sTail = stu;
	}
}

void inGrade (Grade *gra) {
	if (gHead == NULL) {
		gHead = gra;
		gTail = gra;
	}
	else {
		gTail->next = gra;
		gra->next = NULL;
		gTail = gra;
	}
}

void initStudent (char str[]) {
	char buffer[1024];
	char *ch;
	int index = 0, i;

	FILE *fp  = fopen(str, "r");
	if (fp == NULL) {
		printf("%s\n", "Error!");
		return ;
	}
	while (!feof(fp)) {
		//printf("%s\n", "-----");
		fgets(buffer, 1024, fp);
		Student *student = malloc(sizeof(Student));
		ch = (char *)strtok(buffer, " ");
		while (ch != NULL) {
			//printf("%s\n", ch);
			switch (index) {
				case 0: 
					i = atoi(ch);
					student->id = i;
					break;
				case 1: 
					strcpy(student->name, ch);
					break;
				case 2: 
					strcpy(student->sex, ch);
					break;
				case 3: 
					i = atoi(ch);
					student->dorm = i;
					break;
				case 4: 
					i = atoi(ch);
					student->phone = i;
					break;
				default:
					break;
			}
			index++;
			ch = (char *)strtok(NULL, " ");	
		}
		index = 0;
		inStudent(student);
		//free(student);
        //printf("%s\n", buffer);
	}
	printf("\n");
	fclose(fp);
}

void initGrade(char str[]) {
	char buffer[1024];
	char *ch;
	int index = 0, i;


	FILE *fp  = fopen(str, "r");
	if (fp == NULL) {
		printf("%s\n", "Error!");
		return ;
	}
	while (!feof(fp)) {
		fgets(buffer, 1024, fp);
		Grade *grade = malloc(sizeof(Grade));
		ch = (char *)strtok(buffer, " ");
		while (ch != NULL) {
			//printf("%s\n", ch);
			switch (index) {
				case 0: 
					i = atoi(ch);
					grade->id = i;
					break;
				case 1: 
					strcpy(grade->classId, ch);
					break;
				case 2: 
					strcpy(grade->className, ch);
					break;
				case 3: 
					i = atoi(ch);
					grade->credit = i;
					break;
				case 4: 
					i = atoi(ch);
					grade->usual = i;
					break;
				case 5: 
					i = atoi(ch);
					grade->test = i;
					break;
				case 6: 
					i = atoi(ch);
					grade->exam = i;
					break;
				default:
					break;
			}
			index++;
			ch = (char *)strtok(NULL, " ");	
		}
		index = 0;
		if (grade->exam == -1) {
			grade->grade = grade->usual * 0.3 + grade->exam * 0.7;
		} else {
			grade->grade = grade->usual * 0.15 + grade->exam * 0.15 + grade->exam * 0.7;
		}
		if (grade->grade >= 90 && grade->grade <= 100) {
			grade->allCredit = grade->credit;
		} else {
			if (grade->grade >= 80) {
				grade->allCredit = grade->credit * 0.8;
			} else {
				if (grade->grade >= 70) {
					grade->allCredit = grade->credit * 0.75;
				} else {
					if (grade->grade >= 60) {
						grade->allCredit = grade->credit * 0.6;
					} else {
						grade->allCredit = 0;
					}
				}
			}
		}
		inGrade(grade);
        //printf("%s\n", buffer);
	}
	printf("\n");
	fclose(fp);
}

void selectGradeById (int id) {
	int index = 0;
	int creditSum = 0;
	//student
	Student *stu = sHead;
	while (stu != NULL) {
		if (stu->id == id) {
			printf("Id:%d  Name: %s \n", stu->id, stu->name);
		}
		stu = stu->next;
	}
	//grade
	Grade *head = gHead;
	while (head != NULL) {
		if (head->id == id) {
			index++;
			creditSum += head->allCredit;
			printf("ClassId:%s ClassName:%s Grade:%d Credit:%d \n", head->classId, head->className, head->grade, head->allCredit);
		}
		head = head->next;
	}
	printf("Use:%dclasses  AllCredit:%d\n", index, creditSum);
}

void selectStudentById (int id) {
	Student *stu = sHead;
	while (stu != NULL) {
		if (stu->id == id) {
			printf("Id:%d Name:%s Sex:%s Dorm:%d Phone:%d \n", stu->id, stu->name, stu->sex, stu->dorm, stu->phone);
		}
		stu = stu->next;
	}
}

void selectStudentByName (char name[]) {
	Student *stu = sHead;
	while (stu != NULL) {
		if (strcmp(stu->name, name) == 0) {
			printf("Id:%d Name:%s Sex:%s Dorm:%d Phone:%d \n", stu->id, stu->name, stu->sex, stu->dorm, stu->phone);
		}
		stu = stu->next;
	}
}

void selectStudentByDorm (int dorm) {
	Student *stu = sHead;
	while (stu != NULL) {
		if (stu->dorm == dorm) {
			printf("Id:%d Name:%s Sex:%s Dorm:%d Phone:%d \n", stu->id, stu->name, stu->sex, stu->dorm, stu->phone);
		}
		stu = stu->next;
	}
}

void deleteGradeById (int id) {
	if (gHead->id == id) { //Delete Grade Head
		gHead = gHead->next;
		printf("Delete Grade Id : %d\n", id);
		deleteGradeById(id);
		return ;
	}
	Grade *pre = gHead;
	Grade *head = gHead;
	while (head != NULL) {
		if (head->id == id) {
			pre->next = head->next;
			head->next = NULL;
			printf("Delete Grade Id : %d\n", id);
		}
		pre = head;
		head = head->next;
	}
}

void deleteStudentById (int id) {
	if (sHead->id == id) { //Delete Student Head
		sHead = sHead->next;
		printf("Delete Student Id : %d\n", id);
		deleteGradeById(id);
		return ;
	}
	Student *pre = sHead;
	Student *stu = sHead;
	while (stu != NULL) {
		if (stu->id == id) {
			pre->next = stu->next;
			stu->next = NULL;
			printf("Delete Student Id : %d\n", id);
			deleteGradeById(id);
		}
		pre = stu;
		stu = stu->next;
	}
}

void SortByGradeAesc() {
	Grade *head = gHead;
	Grade *next = gHead;
	while (head != NULL) {
		next = head->next;
		while (next != NULL) {
			if (head->grade > next->grade) {
				int temp = head->id; head->id = next->id; next->id = temp;
				char ch1[64]; strcpy(ch1, head->classId); strcpy(head->classId, next->classId); strcpy(next->classId, ch1);	
				char ch2[64]; strcpy(ch2, head->className); strcpy(head->className, next->className); strcpy(next->className, ch2);
				temp = head->credit; head->credit = next->credit; next->credit = temp;
				temp = head->usual; head->usual = next->usual; next->usual = temp;
				temp = head->test; head->test = next->test; next->test = temp;
				temp = head->exam; head->exam = next->exam; next->exam = temp;
				temp = head->grade; head->grade = next->grade; next->grade = temp;
				temp = head->allCredit; head->allCredit = next->allCredit; next->allCredit = temp;
			}
			next = next->next;
		}
		head = head->next;
	}
	Print("grade");
}

void SortByGradeDesc() {
	Grade *head = gHead;
	Grade *next = gHead;
	while (head != NULL) {
		next = head->next;
		while (next != NULL) {
			if (head->grade < next->grade) {
				int temp = head->id; head->id = next->id; next->id = temp;
				char ch1[64]; strcpy(ch1, head->classId); strcpy(head->classId, next->classId); strcpy(next->classId, ch1);
				char ch2[64]; strcpy(ch2, head->className); strcpy(head->className, next->className); strcpy(next->className, ch2);
				temp = head->credit; head->credit = next->credit; next->credit = temp;
				temp = head->usual; head->usual = next->usual; next->usual = temp;
				temp = head->test; head->test = next->test; next->test = temp;
				temp = head->exam; head->exam = next->exam; next->exam = temp;
				temp = head->grade; head->grade = next->grade; next->grade = temp;
				temp = head->allCredit; head->allCredit = next->allCredit; next->allCredit = temp;
			}
			next = next->next;
		}
		head = head->next;
	}
	Print("grade");
}

void SortByCreditAesc() {
	Grade *head = gHead;
	Grade *next = gHead;
	while (head != NULL) {
		next = head->next;
		while (next != NULL) {
			if (head->allCredit > next->allCredit) {
				int temp = head->id; head->id = next->id; next->id = temp;
				char ch1[64]; strcpy(ch1, head->classId); strcpy(head->classId, next->classId); strcpy(next->classId, ch1);
				char ch2[64]; strcpy(ch2, head->className); strcpy(head->className, next->className); strcpy(next->className, ch2);
				temp = head->credit; head->credit = next->credit; next->credit = temp;
				temp = head->usual; head->usual = next->usual; next->usual = temp;
				temp = head->test; head->test = next->test; next->test = temp;
				temp = head->exam; head->exam = next->exam; next->exam = temp;
				temp = head->grade; head->grade = next->grade; next->grade = temp;
				temp = head->allCredit; head->allCredit = next->allCredit; next->allCredit = temp;
			}
			next = next->next;
		}
		head = head->next;
	}
	Print("grade");
}

void SortByCreditDesc() {
	Grade *head = gHead;
	Grade *next = gHead;
	while (head != NULL) {
		next = head->next;
		while (next != NULL) {
			if (head->allCredit < next->allCredit) {
				int temp = head->id; head->id = next->id; next->id = temp;
				char ch1[64]; strcpy(ch1, head->classId); strcpy(head->classId, next->classId); strcpy(next->classId, ch1);
				char ch2[64]; strcpy(ch2, head->className); strcpy(head->className, next->className); strcpy(next->className, ch2);
				temp = head->credit; head->credit = next->credit; next->credit = temp;
				temp = head->usual; head->usual = next->usual; next->usual = temp;
				temp = head->test; head->test = next->test; next->test = temp;
				temp = head->exam; head->exam = next->exam; next->exam = temp;
				temp = head->grade; head->grade = next->grade; next->grade = temp;
				temp = head->allCredit; head->allCredit = next->allCredit; next->allCredit = temp;
			}
			next = next->next;
		}
		head = head->next;
	}
	Print("grade");
}

void writeTo (char str[]) {
	char ch[128];

	FILE *fp  = fopen(str, "w");
	if (fp == NULL) {
		printf("%s\n", "Error!");
		return ;
	}
	if (str == "a.txt") {
		Student *head = sHead;
		while (head != NULL) {
			fprintf(fp, "%d %s %s %d %d\n", head->id, head->name, head->sex, head->dorm, head->phone);
			//printf("%s\n", "++++");
			head = head->next;
		}
	} else {
		if (str == "b.txt") {
			Grade *head = gHead;
			while (head != NULL) {
				fprintf(fp, "%d %s %s %d %d %d %d\n", head->id, head->classId, head->className, head->credit, head->usual, head->test, head->exam);
				//printf("%s\n", "++++");
				head = head->next;
			}
		} else {
			printf("%s\n", "Error!");
		}
	}
	fclose(fp);
}

int main() {

	//Init
	initStudent("a.txt");
	initGrade("b.txt");

	//Print
	Print("grade");
	Print("student");
	
	char choice;
	char name[64];
    int id, dorm;

    //Operating Main
 	while (1) {
		puts("        * * * *          System Operating         * * *");
		puts("        ***********************************************");
		puts("        *                                             *");
		printf("        *    1 ]. Select By Student Id                *\n");
		puts("        *                                             *");
		printf("        *    2 ]. Select By Student Name              *\n");
		puts("        *                                             *");
		printf("        *    3 ]. Select By Student Dorm              *\n");
		puts("        *                                             *");
		printf("        *    4 ]. Select By Grade Id                  *\n");
		puts("        *                                             *");
		printf("        *    5 ]. Delete Student Id                   *\n");
		puts("        *                                             *");
		printf("        *    6 ]. Sort By Student grade Aesc          *\n");
		puts("        *                                             *");
		printf("        *    7 ]. Sort By Student grade Desc          *\n");
		puts("        *                                             *");
		printf("        *    8 ]. Sort By Student credit Aesc         *\n");
		puts("        *                                             *");
		printf("        *    9 ]. Sort By Student credit Desc         *\n");
		puts("        *                                             *");
		printf("        *    0 ]. Exit                                *\n");
		puts("        *                                             *");
		puts("        ***********************************************");
		printf("Choose (0 to 9):  ");
		choice = getchar();

		puts("");
		getchar();
		switch (choice) {
			case '1':
				printf("%s\n", "Please input Student Id : ");
				scanf("%d", &id);
				selectStudentById(id);
				printf("\nPress Enter to continue...\n");
				getchar();
				break;
			case '2':
				printf("%s\n", "Please input Student name : ");
				scanf("%s", &name);
				selectStudentByName(name);
				printf("\nPress Enter to continue...\n");
				getchar();
				break;
			case '3':
				printf("%s\n", "Please input Student Dorm : ");
				scanf("%d", &dorm);
				selectStudentByDorm(dorm);
				printf("\nPress Enter to continue...\n");
				getchar();
				break;
			case '4':
				printf("%s\n", "Please input Grade Id : ");
				scanf("%d", &id);
				selectGradeById(id);
				printf("\nPress Enter to continue...\n");
				getchar();
				break;
			case '5':
			    printf("%s\n", "Please input Student Id : ");
				scanf("%d", &id);
				deleteStudentById(id);
				printf("\nPress Enter to continue...\n");
				getchar();
				break;
			case '6':
				SortByGradeAesc();
				printf("\nPress Enter to continue...\n");
				getchar();
				break;
			case '7':
				SortByGradeDesc();
				printf("\nPress Enter to continue...\n");
				getchar();
				break;
			case '8':
			    SortByCreditAesc();
				printf("\nPress Enter to continue...\n");
				getchar();
				break;
			case '9':
				SortByCreditDesc();
				printf("\nPress Enter to continue...\n");
				getchar();
				break;
			case '0':
				writeTo("a.txt");
				writeTo("b.txt");
				return 0;
				break;
		}
	}

	return 0;
}