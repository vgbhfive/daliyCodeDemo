#include "node.h"
#include <iostream>
#include <stddef.h>
#include <stdlib.h>
#include <stdio.h>

using namespace std;

template<typename T> class CircularList {
public:
    CircularList():head(new ListNode<T>()) {
        head->m_pnext = head;
    }
    ~CircularList() {
        EmptyList();
        delete head;
    }
public:
    void EmptyList();
    int Length();
    bool Insert(T item, int n = 0);
    T Delete(int n);
    void DeleteNode(T n);
    void Print();
    void Sort();
    void Split(CircularList<char>* intList, CircularList<char>* charList, CircularList<char>* otherList);
private:
    ListNode<T>* head;
};

template<typename T> void CircularList<T>::EmptyList() { //清空链表
    ListNode<T>* p = head, *pdel;
    while (p->m_pnext != head) {//清空链表上所有结点的值
        pdel = p->m_pnext;
        p->m_pnext = pdel->m_pnext;
        delete pdel;
    }
}

template<typename T> int CircularList<T>::Length() { //计算链表长度
    int count = 0;
    ListNode<T>* p = head;
    while (p->m_pnext != head) {//循环链表，计算长度
        count ++ ;
        p = p->m_pnext;
    }
    return count;
}

template<typename T> bool CircularList<T>::Insert(T item, int n) { //插入元素
    if(n < 0 || n > Length()) {//判断非法输入
        return false;//n出界
    }
    ListNode<T>* p = head;
    ListNode<T>* pnewnode = new ListNode<T>(item);//定义结点
    if(pnewnode == NULL) {
        return false;//结点是否获取正确
    }
    for(int i = 0; i < n; i++) {
        p = p->m_pnext;
        if(p == head)
            return false;//n出界
    }
    pnewnode->m_pnext = p->m_pnext;//结点赋值
    p->m_pnext = pnewnode;
    return true;
}

template<typename T> T CircularList<T>::Delete(int n) { //删除第n个元素
    if(n < 0 || n > Length()) {//判断非法输入
        return -1;
    }
    ListNode<T>* p  = head,*pdel;
    for(int i = 0; i < n; i++) { //找到第n个元素
        p = p->m_pnext;
    }
    //删除第n个结点
    pdel = p->m_pnext;
    p->m_pnext = pdel->m_pnext;
    T data = pdel->m_data;
    delete pdel;//删除结点
    return data;
}

template<typename T> void CircularList<T>::DeleteNode(T n) { //删除指定值的元素
    ListNode<T>* p = head->m_pnext;
    ListNode<T>* pre = head;
    while (p != head) {// 遍历所有结点，匹配对应的值，即删除对应结点
        if (p->m_data == n) {
            pre->m_pnext = NULL;
            pre->m_pnext = p->m_pnext;
        }
        pre = p;
        p = p->m_pnext;//下一个结点
    }
}

template<typename T> void CircularList<T>::Print() { //输出链表
    ListNode<T>* p = head;
    cout << "head" ;
    while(p->m_pnext != head) { // 遍历所有的结点，输出结点数据
        p = p->m_pnext;
        cout << "-->" << p->m_data;
    }
    cout << endl;
}

template<typename T> void CircularList<T>::Sort() { //冒泡排序
    ListNode<T>* p = head;
    ListNode<T>* p1 = head;
    while (p->m_pnext != head) {
        p = p->m_pnext;//获取待比较的值
        p1 = p;
        T data = p->m_data;
        while (p1->m_pnext != head) { //与后续的值作比较，最小的结点向前运动
            p1 = p1->m_pnext;
            if (p1->m_data <= p->m_data) {
                T temp = p1->m_data;
                p1->m_data = p->m_data;
                p->m_data = temp;
            }
        }

    }
    Print();
}

template<typename T> void CircularList<T>::Split(CircularList<char>* intList, 
	CircularList<char>* charList, CircularList<char>* otherList) { //排序
    ListNode<T>* p = head;
    while (p->m_pnext != head) { //循环所有结点
        p = p->m_pnext;
        char ch = p->m_data;
        if (((ch>='a')&&(ch<='z'))||((ch>='A')&&(ch<='Z'))) { //匹配字母
        	charList->Insert(ch);
        } else {
        	if ((ch>='0')&&(ch<='9')) { //匹配数字
	        	intList->Insert(ch);
        	} else { //匹配其他的值
        		otherList->Insert(ch);
        	}
        }
    }
}

int main () {

    CircularList<char> circularlist;
    //插入节点值
    cout << "Insert node : " << endl;
    circularlist.Insert('d');
    circularlist.Insert('e');
    circularlist.Insert('t');
    circularlist.Insert('q');
    circularlist.Insert('w');
    circularlist.Insert('e');
    circularlist.Insert('y');
    circularlist.Insert('u');
    circularlist.Insert('j');
    circularlist.Insert('l');
    circularlist.Insert('d');
    circularlist.Insert('4');
    circularlist.Insert('8');
    circularlist.Insert('2');
    circularlist.Insert('2');
    circularlist.Insert('\\');
    circularlist.Insert('`');
    circularlist.Insert('.');
    circularlist.Insert('|');
    circularlist.Insert(',');
    circularlist.Print();
    
    CircularList<char> intList;
	CircularList<char> charList;
	CircularList<char> otherList;

    char x, choice, del;
    int index;

    while (1) {
		puts("        * * * *          System Operating         * * *");
		puts("        ***********************************************");
		puts("        *                                             *");
		printf("        *    1 ]. Insert Node                         *\n");
		puts("        *                                             *");
		printf("        *    2 ]. The length of list:                 *\n");
		puts("        *                                             *");
		printf("        *    3 ]. delete node element                 *\n");
		puts("        *                                             *");
		printf("        *    4 ]. delete index element                *\n");
		puts("        *                                             *");
		printf("        *    5 ]. Split                               *\n");
		puts("        *                                             *");
		printf("        *    6 ]. Print                               *\n");
		puts("        *                                             *");
		printf("        *    7 ]. Exit                                *\n");
		puts("        *                                             *");
		puts("        ***********************************************");
		printf("   Choose (1 to 7):");
		choice = getchar();

		puts("");
		getchar();
		switch (choice) {
		case '1':
			printf("%s\n", "insert node char : ");
			cin >> x;
			circularlist.Insert(x);
			printf("\nPress Enter to continue...\n");
			getchar();
			break;
		case '2':
			cout << "The Length of list : \n" << circularlist.Length() << endl;
			printf("\nPress Enter to continue...\n");
			getchar();
			break;
		case '3':
			cout << "input delete node : " << endl;  
			cin >> x;
			circularlist.DeleteNode(x);
			printf("\nPress Enter to continue...\n");
			getchar();
			break;
		case '4':
			cout << "input delete index : " << endl;  
			cin >> index;
			del = circularlist.Delete(index);
			printf("\nPress Enter to continue...\n");
			getchar();
			break;
		case '5':
		    circularlist.Split(&intList, &charList, &otherList);
		    intList.Sort();
		    charList.Sort();
		    otherList.Sort();
			printf("\nPress Enter to continue...\n");
			getchar();
			break;
		case '6':
			circularlist.Print();
			printf("\nPress Enter to continue...\n");
			getchar();
			break;
		case '7':
			return 0;
			break;
		}
		
	}

    return 0;
}