#include <stddef.h>

template<typename T> class CircularList;

template<typename T> class ListNode {
public:
    friend class CircularList<T>;
    ListNode():m_pnext(NULL) {

    }
    ListNode(const T data, ListNode<T>* pnext = NULL):m_data(data),m_pnext(pnext) {

    }
    ~ListNode() {
        m_pnext = NULL;
    }

private:
    T m_data;
    ListNode<T>* m_pnext;
};