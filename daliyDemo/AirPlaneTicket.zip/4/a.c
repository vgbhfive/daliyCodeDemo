#include <stdio.h>
#include <string.h>
#include <stdlib.h>

typedef struct Airplane {
	char airplaneId[32];
	char takeoffCity[32];
	char landCity[32];
	char time[32];
	int price;
	double discount;
	int nums;

	struct Airplane *next;
}Airplane;

typedef struct Ticket {
	int ticketId;
	char airplaneId[32];
	char idcard[32];

	struct Ticket *next;
}Ticket;

typedef struct User {
	char idcard[32];
	char name[32];
	int tickets;

	struct User *next;
}User;

Airplane *aHead = NULL;
Airplane *aTail = NULL;
Ticket *tHead = NULL;
Ticket *tTail = NULL;
User *uHead = NULL;
User *uTail = NULL;

int TICKETID = 1000010;

void Print(char str[]) {
	if (str == "air") {
		Airplane *head = aHead;
		while (head != NULL) {
			printf("%s %s %s %s %d %.3f %d \n", head->airplaneId, head->takeoffCity, head->landCity, head->time, head->price, head->discount, head->nums);
			head = head->next;	
		}
	} else {
		if (str == "ticket") {
			Ticket *head = tHead;
			while (head != NULL) {
				printf("%d %s %s \n", head->ticketId, head->airplaneId, head->idcard);
				head = head->next;
			}
		} else {
			if (str == "user") {
				User *head = uHead;
				while (head != NULL) {
					printf("%s %s %d \n", head->idcard, head->name, head->tickets);
					head = head->next;
				}
			} else {
				printf("%s\n", "No thing to print!");
			}
		}
	}
}

void inAirplane(Airplane *air) {
	if (aHead == NULL) {
		aHead = air;
		aTail = air;
	}
	else {
		aTail->next = air;
		air->next = NULL;
		aTail = air;
	}
}

void inAirplaneTicket(Ticket *ticket) {
	if (tHead == NULL) {
		tHead = ticket;
		tTail = ticket;
	} else {
		tTail->next = ticket;
		ticket->next = NULL;
		tTail = ticket;
	}
}

void inUser(User *user) {
	if (uHead == NULL) {
		uHead = user;
		uTail = user;
	} else {
		uTail->next = user;
		user->next = NULL;
		uTail = user;
	}
}

void initAirplane (char str[]) {
	char buffer[1024];
	char *ch;
	int index = 0;

	FILE *fp  = fopen(str, "r");
	if (fp == NULL) {
		printf("%s\n", "Error!");
		return ;
	}
	while (!feof(fp)) {
		fgets(buffer, 1024, fp);
		Airplane *air = malloc(sizeof(Airplane));
		ch = (char *)strtok(buffer, " ");
		while (ch != NULL) {
			//printf("%s\n", ch);
			switch (index) {
				case 0: 
					strcpy(air->airplaneId, ch);
					break;
				case 1: 
					strcpy(air->takeoffCity, ch);
					break;
				case 2: 
					strcpy(air->landCity, ch);
					break;
				case 3: 
					strcpy(air->time, ch);
					break;
				case 4: 
					air->price = atoi(ch);
					break;
				case 5: 
					air->discount = atof(ch);
					break;
				case 6	: 
					air->nums = atoi(ch);
					break;
				default:
					break;
			}
			index++;
			ch = (char *)strtok(NULL, " ");	
		}
		index = 0;
		inAirplane(air);
        //printf("%s\n", buffer);
	}
	printf("\n");
	fclose(fp);
}

Airplane* selectAirplaneById(char id[]) {
	Airplane *head = aHead;
	while (head != NULL) {
		if (strcmp(head->airplaneId, id)) {
			return head;
		}
		head = head->next;
	}
	return NULL;
}

void selectAirplaneByLandcity(char landCity[]) {
	int flag = 0;
	Airplane *head = aHead;
	while (head != NULL) {
		if (!strcmp(head->landCity, landCity)) {
			flag = 1;
			printf("%s %s %s %s %d %f %d \n", head->airplaneId, head->takeoffCity, head->landCity, head->time, head->price, head->discount, head->nums);
		}
		head = head->next;
	}
	if (!flag) {
		printf("%s\n", "Nothing Airplane!");
	}
}

int empty(char id[]) {
	Airplane *head = aHead;
	while (head != NULL) {
		if (!strcmp(head->airplaneId, id)) {
			return 1;
		}
		head = head->next;
	}
	return 0;
}

int emptyUser(char id[]) {
	User *user = uHead;
	while (user != NULL) {
		if (!strcmp(user->idcard, id)) {
			return 1;
		}
		user = user->next;
	}
	return 0;
}

void insertAirplane() {
	Airplane *air = malloc(sizeof(Airplane));

	printf("%s\n", "Please Input Airplane Id: ");
	scanf("%s", &air->airplaneId);
	printf("%s\n", "Please Input Take off City: ");
	scanf("%s", &air->takeoffCity);
	printf("%s\n", "Please Input Land City: ");
	scanf("%s", &air->landCity);
	printf("%s\n", "Please Input Tiem: ");
	scanf("%s", &air->time);
	printf("%s\n", "Please Input Price: ");
	scanf("%d", &air->price);
	printf("%s\n", "Please Input Discount: ");
	scanf("%lf", &air->discount);
	printf("%s\n", "Please Input Nums of User: ");
	scanf("%d", &air->nums);

	inAirplane(air);
	printf("%s\n", "Successful Insert!\n");
}

void insertUser() {
	User *user = malloc(sizeof(User));

	printf("%s\n", "Please Input User idcard: ");
	scanf("%s", &user->idcard);
	if (emptyUser(user->idcard)) {
		printf("%s\n", "Repeat Id card!");
		return ;
	}
	printf("%s\n", "Please Input User name: ");
	scanf("%s", &user->name);
	printf("%s\n", "Please Input tickets Num: ");
	scanf("%d", &user->tickets);

	inUser(user);
	printf("%s\n", "Successful Insert!\n");
}

void issueTicket() {
	Ticket *ticket = malloc(sizeof(Ticket));

	TICKETID += 1;
	ticket->ticketId = TICKETID;
	printf("%s\n", "Please Input Airplane Id: ");
	scanf("%s", &ticket->airplaneId);
	if (!empty(ticket->airplaneId)) {
		printf("%s\n", "Nothing This Airplane!");
		return ;
	}
	Airplane *air = selectAirplaneById(ticket->airplaneId);
	if (air->nums <= 0) {
		printf("%s\n", "No Tickets From Airplane!");
		return ;
	} else {
		air->nums -= 1;
	}
	printf("%s\n", "Please Input your Id card: ");
	scanf("%s", &ticket->idcard);
	if (!emptyUser(ticket->idcard)) {
		printf("%s\n", "Nothing This User! You must Insert yourself!");
		return;
	}

	inAirplaneTicket(ticket);
	printf("%s\n", "Successful Issue!");
}

int main () {

	//Init
	initAirplane("air.txt");

	//Print
	Print("air");

	char id[32], landCity[32], ch[32];
	char choice;

	while (1) {
		puts("        *******************飞机订票系统菜单**************");
		puts("        ***********************************************");
		puts("        *                                             *");
		printf("        *   -------- 1 ]. 插入航班信息 	      *\n");
		puts("        *                                             *");
		printf("        *   -------- 2 ]. 通过Id查询飞机 	      *\n");
		puts("        *                                             *");
		printf("        *   -------- 3 ]. 通过城市查询飞机    *\n");
		puts("        *                                             *");
		printf("        *   -------- 4 ]. 订票                      *\n");
		puts("        *                                             *");
		printf("        *   -------- 5 ]. 插入个人信息          *\n");
		puts("        *                                             *");
		printf("        *   -------- 6 ]. 输出飞机和机票信息  *\n");
		puts("        *                                             *");
		printf("        *   -------- 0 ]. 退出                      *\n");
		puts("        *                                             *");
		puts("        ***********************************************");
		printf(" 选择你需要的服务 (0 to 6):  ");
		choice = getchar();

		puts("");
		getchar();
		switch (choice) {
			case '1':
				insertAirplane();
				printf("\nPress Enter to continue...\n");
				getchar();
				break;
			case '2':
				printf("%s", "Please input a number :");
				scanf("%s", &id);
				Airplane *air = selectAirplaneById(id);
				printf("%s %s %s %s %d %f %d \n", air->airplaneId, air->takeoffCity, air->landCity, air->time, air->price, air->discount, air->nums);
				printf("\nPress Enter to continue...\n");
				getchar();
				break;
			case '3':
				printf("%s", "Please input landCity :");
				scanf("%s", &landCity);
				selectAirplaneByLandcity(landCity);
				printf("\nPress Enter to continue...\n");
				getchar();
				break;
			case '4':
				issueTicket();
				printf("\nPress Enter to continue...\n");
				getchar();
				break;
			case '5':
				insertUser();
				printf("\nPress Enter to continue...\n");
				getchar();
				break;
			case '6':
				Print("air");
				Print("ticket");
				printf("\nPress Enter to continue...\n");
				getchar();
				break;
			case '0':
				return 0;
				break;
		}	
	}

	return 0;
}