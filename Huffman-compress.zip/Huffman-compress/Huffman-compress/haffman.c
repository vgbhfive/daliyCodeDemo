﻿#include <unistd.h>
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>

#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>

#define  N 256
#define Maxsize 80
#define  some 1
#define Empty 0
#define FULL -1

typedef unsigned long int weight;
typedef unsigned char byte;

typedef struct			//哈夫曼树
{
	byte ch;		//存字符
	weight weight;	/* 用来存放各个结点的权值 */
	int parent, left_child, right_child;	/*指向双亲、孩子结点的指针 */
} HuffNode;

typedef struct			//队列
{
	char is_empty;
	int head;
	int tail;
	int length;
	byte elem[Maxsize];
} Queue;

void out_file();
void print_huff(HuffNode * ht, int n);
void code(char **hc, int n, unsigned char *ch);

int create_queue(Queue * Q)
{
	if (!Q)
		return 1;
	Q->tag = Empty;
	Q->front = Q->rear = 0;
	Q->length = 0;

	return 0;
}

int In_seqQueue(Queue * Q, char x)
{
	if (Q->front == Q->rear && Q->tag == some)
		return FULL;	//full

	Q->elem[Q->rear] = x;	// printf("in = %c",x);
	Q->rear = (Q->rear + 1) % Maxsize;
	Q->length++;
	Q->tag = some;
	return some;
}

int Out_Queue(Queue * Q, char *x)
{
	if (Q->tag == Empty)
		return Empty;

	*x = Q->elem[Q->front];
	Q->length--;
	Q->front = (Q->front + 1) % Maxsize;

	if (Q->front == Q->rear)
		Q->tag = Empty;

	return some;
}

/* ------------------以上是队列的操作-------------------------  */

void SelectMinTree(HuffNode * ht, int n, int *k)
{
	int i, temp;
	weight min;

	//      printf(" Selecting……n= %d",n);
	for (i = 0; i <= n; i++) {
		if (0 == ht[i].parent) {
			min = ht[i].weight;	//init min
			temp = i;
			break;
		}
	}
	for (i++; i <= n; i++) {
		if (0 == ht[i].parent && ht[i].weight < min) {
			min = ht[i].weight;
			temp = i;
		}
	}
	*k = temp;
}

// 对哈夫曼树排序，并统计叶子数量
int SortTree(HuffNode * ht)
{
	short i, j;
	HuffNode tmp;

	for (i = N - 1; i >= 0; i--) {
		for (j = 0; j < i; j++)
			if (ht[j].weight < ht[j + 1].weight) {
				tmp = ht[j];
				ht[j] = ht[j + 1];
				ht[j + 1] = tmp;
			}
	}
	for (i = 0; i < N; i++)
		if (0 == ht[i].weight)
			return i;
	return i;		//返回叶子个数
}

//求哈夫曼0-1字符编码表
char **CrtHuffmanCode(HuffNode * ht, short LeafNum)//从叶子结点到根，逆向求每个叶子结点对应的哈夫曼编码
{
	char *cd, **hc;		//容器
	int i, start, p, last;

	hc = (char **)malloc((LeafNum) * sizeof(char *));	//分配n个编码的头指针

	if (1 == LeafNum)	//只有一个叶子节点时 
	{
		hc[0] = (char *)malloc((LeafNum + 1) * sizeof(char));
		strcpy(hc[0], "0");
		return hc;
	}

	cd = (char *)malloc((LeafNum + 1) * sizeof(char));	//分配求当前编码的工作空间
	cd[LeafNum] = '\0';	//从右向左逐位存放编码，首先存放编码结束符

	for (i = 0; i < LeafNum; i++) {	//求n个叶子结点对应的哈夫曼编码
		start = LeafNum;	//初始化编码起始指针
		last = i;
		for (p = ht[i].parent; p != 0; p = ht[p].parent) {	//从叶子到根结点求编码
			if (ht[p].LChild == last)
				cd[--start] = '0';	//左分支标0
			else
				cd[--start] = '1';	//右分支标1
			last = p;
		}

		hc[i] = (char *)malloc((LeafNum - start) * sizeof(char));	//为第i个编码分配空间
		strcpy(hc[i], &cd[start]);
		
		//printf("%3dNumber: %3c CodeLength:%2d;Coding:%s\n", ht[i].ch, ht[i].ch, LeafNum - start, &cd[start]);
	}
	free(cd);
	return hc;
}

HuffNode *CreatHFM(FILE * fp, short *n, weight * FileLength)
{
	HuffNode *ht = NULL;
	int i, m, s1, s2;
	byte ch;

	

	ht = (HuffNode *) malloc(2 * N * sizeof(HuffNode));
	if (!ht)
		exit(1);

	for (i = 0; i < N; i++) {
		ht[i].weight = 0;
		ht[i].ch = (byte) i;	//1-n号ch 为字符，初始化
	}

	for (*FileLength = 0; !feof(fp); ++(*FileLength)) {
		fread(&ch, 1, 1, fp);
		ht[ch].weight++;
		//printf("%c\n", ch);
 	}

	int max=ht[0].weight, min=10;
 	for (i = 1; i < N; i++) {
 		if (ht[i].weight > max) {
 			max = ht[i].weight;
 		}
 		if (ht[i].weight < min && ht[i].weight != 0) {
 			min = ht[i].weight;
 		}
 	}

 	printf("MaxNum:%d --- MinNum:%d\n", max, min);

	--(*FileLength);	//去掉文件结束后的长度
	*n = SortTree(ht);
	m = *n * 2 - 1;		//free(&ht[m+1]);

	if (1 == *n) {
		ht[0].parent = 1;
		return ht;
	} else if (0 > *n)
		return NULL;

	for (i = m - 1; i >= 0; i--) {
		ht[i].LChild = 0;
		ht[i].parent = 0;
		ht[i].RChild = 0;
	}
	
	for (i = *n; i < m; i++) //创建非叶子结点,建哈夫曼树
	{ 
		//在ht[0]~ht[i-1]的范围内选择两个parent为0且weight最小的结点，其序号分别赋值给s1、s2返回
		SelectMinTree(ht, i - 1, &s1);
		ht[s1].parent = i;
		ht[i].LChild = s1;

		SelectMinTree(ht, i - 1, &s2);
		ht[s2].parent = i;
		ht[i].RChild = s2;

		ht[i].weight = ht[s1].weight + ht[s2].weight;
	}

	return ht;
}

//从队列里取8个字符（0、1），转换成一个字节
byte GetBits(Queue * Q)
{
	byte i, bits = 0;
	char x;

	for (i = 0; i < 8; i++) {
		if (Out_Queue(Q, &x) != Empty) {	//printf("%c",x);
			if ('0' == x)
				bits = bits << 1;
			else
				bits = (bits << 1) | 1;
		} else
			break;
	}			//printf("   bits=%d\n",bits);puts("");

	return bits;
}

//求最长（最短）编码长度
void MaxMinLength(FILE * File, HuffNode * ht, char **hc, short NLeaf, byte * Max, byte * Min)
{
	int i;
	byte length;
	char maxChar, minChar;

	*Max = *Min = 3;
	for (i = 0; i < NLeaf; i++) {
		length = strlen(hc[i]);
		//fwrite(&ht[i].ch, sizeof(MyType), 1, File);	//字符和对应的
		//fwrite(&length, sizeof(MyType), 1, File);	//编码长度写进文件
		fprintf(File, "%c\n", ht[i].ch);
		fprintf(File, "%c\n", length);
		if (length > *Max) {
			*Max = length;
			maxChar = ht[i].ch;
		}
		if (length < *Min) {
			*Min = length;
			minChar = ht[i].ch;
		}
	}
	printf("MaxChar: %c -- MinChar: %c  \n", minChar,  maxChar);
}

//把出现过的字符编码表经过压缩写进文件
short CodeToFile(FILE * fp, char **hc, short n, Queue * Q, byte * length)
{
	int i;
	char *p;
	byte j, bits;
	short count = 0;

	for (i = 0; i < n; i++)	// 将n个叶子压缩并写入文件
	{
		for (p = hc[i]; '\0' != *p; p++)
			In_seqQueue(Q, *p);

		while (Q->length > 8) {	//  puts("出队");
			bits = GetBits(Q);	//出队8个元素
			fwrite(&bits, sizeof(char), 1, fp);
			//printf("code: %d\n",bits);
			count++;
		}
	}

	//剩余不足8个元素
	*length = Q->length;
	i = 8 - *length;
	bits = GetBits(Q);	//取8个如果队不空
	for (j = 0; j < i; j++)
		bits = bits << 1;	//printf("压 字符 %c\n",bits);
	fputc(bits, fp);	//fwrite(&bits,sizeof(char),1,fp);
	count++;		//printf(" 指 针 在%d \n",ftell(fp));

	create_queue(Q);
	return count;
}

//压缩
void Compress()
{
	byte maxLen, minLen, ch, bits, n, finalLength;
	int i;
	short LeafNum, codeNum;
	weight count = 0, Length = 0, FileLength;
	FILE *fp, *compressFile;
	Queue *Q;
	HuffNode *ht = NULL;
	char **hc = NULL, **Map = NULL, *p;

	fp = fopen("english.txt", "rb"); //打开原文件
	compressFile = fopen("encoding.txt", "wb"); //创建编码压缩文件

	ht = CreatHFM(fp, &LeafNum, &FileLength); //创建哈夫曼树,统计叶子个数和原文件长度
	if (!FileLength) { //printf("文件为空，无须压缩...");
		fclose(fp);
		free(ht);
		return; //关闭文件及输入输出流，并返回
	}

	Q = (Queue *) malloc(sizeof(Queue));
	create_queue(Q); //SEEK_SET:文件开头 SEEK_CUR:当前位置 SEEK_END:文件结尾
	hc = CrtHuffmanCode(ht, LeafNum); //取得哈夫曼0、1编码,hc的长度为LeafNum

	//Map为了取编码好定位，再建立全部(256个)
	Map = (char **)malloc(N * sizeof(char *)); //字符编码表
	if (!Map) {
		puts("申请空间失败");
		return;
	}

	for (i = 0; i < N; i++)	
		Map[i] = NULL; //初始化
	for (i = 0; i < LeafNum; i++) {
		Map[(int)(ht[i].ch)] = hc[i]; // 定位，编码指针数组Map[256]
	}	

	fseek(compressFile, sizeof(weight) + sizeof(short) + 6 * sizeof(byte), SEEK_SET);	//占据文件位置 
	// SEEK_SET 从距文件开头offset位移量为新的读写位置. SEEK_CUR以目前的读写位置往后增加offset个位移量.
	//SEEK_END将读写位置指向文件尾后再增加offset个位移量. 

	MaxMinLength(compressFile, ht, hc, LeafNum, &maxLen, &minLen);	//获得最长码串长度,顺便填写字符对应编码长
	free(ht);
	codeNum = CodeToFile(compressFile, hc, LeafNum, Q, &finalLength);	//把字符转成其二进制编码写入文件,返回压成多少个

	rewind(compressFile);	//使文件指针移到compressFile

	fseek(compressFile, sizeof(weight) + sizeof(byte) + 1, SEEK_SET);
	//fprintf(compressFile, "%d\n", LeafNum); //写入叶子个数
	//fprintf(compressFile, "%d\n", maxLen); //最长码串长度
	//fprintf(compressFile, "%d\n", minLen); //最短码串长度
	//fprintf(compressFile, "%d\n", codeNum); //填写叶子编码压多少个
	//fprintf(compressFile, "%d\n", finalLength); //最后剩余长度

	//输出
	printf("NodeLeaf:%d\n",LeafNum);
	printf("MaxLength = %d\nMinLength= %d\n",maxLen,minLen);
	printf("codeNum:%d\n", codeNum);
	printf("finalLength:%d\n", finalLength);

	fseek(compressFile, 2 * LeafNum * sizeof(byte) + codeNum , SEEK_CUR);
	fseek(fp, 0, SEEK_SET);
	printf("Please wait a minute,compressing...");//开始压缩
	fseek(compressFile, sizeof(weight) + sizeof(short) + 6 * sizeof(byte), SEEK_SET);//字符转码存储区域，前边都是一些关于哈夫曼树的信息

	while (count < FileLength) {
		fread(&ch,sizeof(byte),1,fp);        
		++count;
		for (p = Map[ch]; *p != '\0'; p++) {
			In_seqQueue(Q, *p);
		}

		while (Q->length > 8)
		{
			bits = GetBits(Q);	//出队8个元素,合成一个字节
			fprintf(compressFile, "%d\n", bits);
			//printf("%d\n", bits); 
			Length++;
		}
	}

	//最后一个bits
	finalLength = Q->length;
	n = 8 - finalLength;
	bits = GetBits(Q);
	for (i = 0; i < n; i++) {
		bits = bits << 1;	//以‘0’补
	}
	fprintf(compressFile, "%d\n", bits);
	Length++;
	//压缩文件输出结束

	rewind(compressFile);
	fseek(compressFile, 0, SEEK_SET);
	//fprintf(compressFile, "%d\n", Length); //压缩后的长
	//fprintf(compressFile, "%d\n", finalLength); //最后的串长

	Length = Length + 12 + codeNum;	//压缩后的文件长度

	if (Length >= FileLength) {
		puts("\nCompression rate: 0.0%"); //压缩率
	}
	else {
		printf("\nCompression rate: %.2lf%c\n",(double)((FileLength - Length) / (double)FileLength) * 100.0, '%'); //压缩率
	}

	//释放资源和文件
	fclose(fp);
	fclose(compressFile);
	free(Q);
	free(hc);
	free(Map);//关闭文件和流
}

//把读出的字符，转换成8个0、1字符串并入队
void ToQueue(Queue * Q, byte ch)
{
	int i;
	byte temp;

	for (i = 0; i < 8; i++) {
		temp = ch << i;
		temp = temp >> 7;
		if (1 == temp)
			In_seqQueue(Q, '1');	//printf("1");
		else
			In_seqQueue(Q, '0');	//printf("0");
	}			
}

//解压缩
void UnCompress()
{
	byte *str, MaxLength, MinLength, ch, *num, finalLength = 0, final = 0;
	FILE *cf, *uf;
	short NLeaf, Ncom;
	char **hc, *p, x, *buf;
	Queue *Q = NULL;
	int i, j;
	weight srcLen = 0, thisFile = 0;

	cf = fopen("encoding.txt", "rb");
	uf = fopen("english2.txt", "wb");
	if (!cf || !uf) {
		puts("Cannot open files.");
		return;
	}

	// fread(&srcLen, sizeof(WeightType), 1, cf);	
	// fread(&finalLength, sizeof(MyType), 1, cf);
	// fread(&NLeaf, sizeof(short), 1, cf);
	// fread(&MaxLength, sizeof(MyType), 1, cf);
	// fread(&MinLength, sizeof(MyType), 1, cf);
	// fread(&Ncom, sizeof(short), 1, cf);
	// fread(&final, sizeof(MyType), 1, cf);
	srcLen = 129;
	finalLength = 3;
	NLeaf = 29;
	MaxLength = 8;
	MinLength = 2;
	Ncom = 21;
	final = 3;

	printf("srcLen:%d\n",srcLen);
	printf("finalLength:%d\n",finalLength);
	printf("NLeaf:%d\n",NLeaf);
	printf("MaxLength = %d\nminLen= %d\n",MaxLength,MinLength);
	printf("Ncom:%d\n", Ncom);
	printf("final:%d\n", final);

	//申请内存空间
	Q = (Queue *) malloc(sizeof(Queue));
	buf = (char *)malloc((2 + MaxLength * sizeof(char)));
	str = (byte *) malloc(NLeaf * sizeof(byte));
	num = (byte *) malloc(NLeaf * sizeof(byte));
	if (!Q || !str || !num || !buf) {
		puts("Memery error.");
		exit(1);
	}

	create_queue(Q); //初始化

	

	//printf("Q->length= %d\n",Q->length);printf("ftell= %d\n",ftell(uf));
	//释放资源
	free(Q);
	free(str);
	free(num);
	free(hc);
	fclose(uf);
	fclose(cf);
}

int main(int argc, char *argv[])
{
	char choice, blank[] = "              ";
	
	while (1) {
		puts("          * * * *Welcome use huffman encoder\\decoder* * *");
		puts("          ************************************************");
		puts("          *                                              *");
		printf("          * %s 1 ]. Compress   %s*\n", blank, blank);
		puts("          *                                              *");
		printf("          * %s 2 ]. Uncompress%s *\n", blank, blank);
		puts("          *                                              *");
		printf("          * %s 3 ]. Exit  ^_^ %s *\n", blank, blank);
		puts("          *                                              *");
		puts("          ************************************************");
		printf("          Choose (1 to 3):");
		choice = getchar();

		puts("");
		getchar();
		switch (choice) {
		case '1':
			Compress();
			printf("Press Enter to continue...");
			getchar();
			break;
		case '2':
			UnCompress();
			printf("\nPress Enter to continue...");
			getchar();
			break;
		case '3':
			return 0;
			break;
		}
	}

	return 0;
}

