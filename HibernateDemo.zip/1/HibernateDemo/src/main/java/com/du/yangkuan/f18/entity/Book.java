package com.du.yangkuan.f18.entity;

/**
 * @time:
 * @author: Vgbh
 */
public class Book extends Media {
    private String author;

    public Book() {
    }

    public Book(String title, String author) {
        super(title);
        this.author = author;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    @Override
    public int compareTo(Object obj) {
        if (obj instanceof Book) {
            Book book2 = (Book) obj;
            if (this.getTitle().equals(book2.getTitle())) {
                return this.getAuthor().compareTo(book2.getAuthor());
            } else {
                return this.getTitle().compareTo(book2.getTitle());
            }
        } else {
            return 1;
        }
    }

    @Override
    public String toString() {
        return "Book [" + "title=" + this.getTitle() + "\t author=" + author + "]";
    }
}
