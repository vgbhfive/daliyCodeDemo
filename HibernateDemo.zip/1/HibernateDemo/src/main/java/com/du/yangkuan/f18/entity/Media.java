package com.du.yangkuan.f18.entity;

import java.io.Serializable;

/**
 * @time:
 * @author: Vgbh
 */
public abstract class Media implements Serializable, Comparable {

    private String title;

    public Media() {
    }

    public Media(String title) {
        super();
        this.title = title;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    @Override
    public abstract int compareTo(Object obj);
}
