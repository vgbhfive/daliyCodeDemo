package com.du.yangkuan.f18.entity;

/**
 * @time:
 * @author: Vgbh
 */
public class DVD extends Media{

    private Integer year;

    public DVD() {
    }

    public DVD(String title, Integer year) {
        super(title);
        this.year = year;
    }

    public Integer getYear() {
        return year;
    }

    public void setYear(Integer year) {
        this.year = year;
    }

    @Override
    public int compareTo(Object obj) {
        if (obj instanceof DVD) {
            DVD dvd2 = (DVD) obj;
            if (this.getYear().equals(dvd2.getYear())) {
                return this.getYear().compareTo(dvd2.getYear());
            } else {
                return this.getTitle().compareTo(dvd2.getTitle());
            }
        } else {
            return -1;
        }
    }

    @Override
    public String toString() {
        return "DVD [" + "title=" + this.getTitle() + "\t year=" + year +  "]";
    }
}
