package com.du.yangkuan.f18.entity;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.sql.Date;
import java.util.*;

@SuppressWarnings("all")
public class HibernateTest {
    private SessionFactory sessionFactory;
    private Session session;
    private Transaction transaction;
    @Before
    public  void init(){
        sessionFactory=new Configuration().configure().buildSessionFactory();
        session = sessionFactory.openSession();
        transaction = session.beginTransaction();
    }
    @Test//多对一
    public void testManyToOne(){
        ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("Du_spring.xml");

        Book m1 = (Book) context.getBean("m1");
        DVD m2 = (DVD) context.getBean("m2");
        save(m1);
        save(m2);

        List<Media> library = new ArrayList<Media>();

        library.add((Book) context.getBean("m1"));
        library.add((DVD) context.getBean("m2"));
        library.add((DVD) context.getBean("m3"));
        library.add((Book) context.getBean("m4"));
        library.add((DVD) context.getBean("m5"));
        library.add((DVD) context.getBean("m6"));
        library.add((DVD) context.getBean("m7"));
        library.add((DVD) context.getBean("m8"));
        library.add((Book) context.getBean("m9"));
        library.add((Book) context.getBean("m10"));
        library.add((Book) context.getBean("m11"));

        Collections.sort(library);

        for (Object media : library) {
            System.out.println(media);
        }
    }

    /**
     * 存储数据
     * @param obj
     */
    private void save(Object obj) {
        if (obj instanceof Book) {
            Book book = (Book) obj;
            session.save(book);
            System.out.println("insert successful!");
        }
        if (obj instanceof DVD) {
            DVD dvd = (DVD) obj;
            session.save(dvd);
            System.out.println("insert successful!");
        }
    }

    @After
    public  void destroy(){
        transaction.commit();
        session.close();
    }

}