#include "linkstack.h"
#include <string.h>

int Priority(char ch)
{
	switch(ch)
	{
		case '(':
			return 3;
		case '*':
		case '/':
			return 2;
		case '+':
		case '-':
			return 1;
		default:
			return 0;
	}
}

char* join(char *s1, char *s2) {
	char *result = malloc(strlen(s1) + strlen(s2) + 1);
	if (result != NULL) {
		exit(1);
	}
	strcpy(result, s1);
	strcpy(result, s2);

	return result;
}
 
int main()
{
	Stack *s_opt, *s_num;
	char opt[1024] = {0};
	int i = 0, tmp = 0, num1 = 0, num2 = 0;
	int j = 0;
	int out = 0;
	char index = '3';

	if(LinkStackInit(&s_opt) != SUCCESS || LinkStackInit(&s_num) != SUCCESS)
	{
		printf("Init Failure \n");
	}

	//建议输入英文或数字，否则会乱码
	printf("My Classmate : %s\n", "6666");
	printf("My Name : %s\n", "5555"); 
	printf("My ID : %s\n", "22222");
	printf("My Phone : %s\n", "11111");

	printf("Please input: \n");
	scanf("%s", opt);

	for (j = 0; j < strlen(opt); ++j)
	{
		if (((opt[j] >= 65) && opt[j] <= 97) || ((opt[j] >= 97) && (opt[j] <= 122))) {
			printf("%s\n", "Error Input!");
			exit(0);
		}
	}

	while(opt[i] != '\0' || LinkStackEmpty(s_opt) != TRUE)
	{
		if(opt[i] >= '0' && opt[i] <= '9')
		{
			tmp = tmp * 10 + opt[i] - '0';
			i++;
			if(opt[i] > '9' || opt[i] < '0')
			{
				Push(&s_num, tmp);
				tmp = 0;
			}	
		}
		else
		{
			if((opt[i] == ')') && (GetTop(s_opt) == '('))
			{
				Pop(&s_opt);
				i++;
				continue;
			}
					
			if((LinkStackEmpty(s_opt) == TRUE) || (Priority(opt[i]) > Priority(GetTop(s_opt))) ||
				((GetTop(s_opt) == '(') && (opt[i] != ')')))
			{
				Push(&s_opt, opt[i]);
				i++;
				continue;
			}
			
			if( ((opt[i] == '\0') &&( LinkStackEmpty(s_opt) != TRUE)) || ( (opt[i] == ')') && (GetTop(s_opt) != '(') )||
				(Priority(opt[i]) <= Priority(GetTop(s_opt)))	)
			{
				switch(Pop(&s_opt))
				{
					case '+':
						num1 = Pop(&s_num);
						num2 = Pop(&s_num);
						Push(&s_num, (num2 + num1));
					break;	
					case '-':
						num1 = Pop(&s_num);
						num2 = Pop(&s_num);
						Push(&s_num, (num2 - num1));
					break;	
					case '*':
						num1 = Pop(&s_num);
						num2 = Pop(&s_num);
						Push(&s_num, (num2 * num1));
					break;	
					case '/':
						num1 = Pop(&s_num);
						num2 = Pop(&s_num);
						Push(&s_num, (num2 / num1));
					break;	
				}
			}	
		}
	}

	out = GetTop(s_num);
	printf("Output:\n%d \n", out);

	return 0;
}